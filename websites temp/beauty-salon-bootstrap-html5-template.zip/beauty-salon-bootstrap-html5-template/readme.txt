Beauty Salon Bootstrap HTML5 Template is a flat good looking modern and stylish bootstrap theme suitable for small types of businesses such as beauty hair salons, massage center and many others. The template is fully responsive and mobile ready. It has the ability to function faultlessly on all types of browsers and modern devices and adapts suitably on small, big or wide screen resolutions.This template is built using latest Bootstrap framework with html5 and css3 which is very easy to customise. Download for free.  
Key features
-------------
Twitter Bootstrap 3.3.1
Clean & Developer-friendly HTML5 and CSS3 code
100% Responsive Layout Design
One Page
Multipurpose theme
Google Fonts Support
Font Awesome 
Smooth Scrolling 
Fully Customizable
Contact Form


Credits :
-------
=> Design and developed: "WebThemez"  http://webthemez.com
=> Photos used in template: **Unsplash** - http://unsplash.com, http://risewall.com/home-business-team-wallpapers.html
=> For more free web themes: http://webthemez.com
=> Framework : http://getbootstrap.com

Important Note:
---------------
To remove backlink from the template, you need to donate to remove the backlink from the template.
Any question contact us: webthemez@gmail.com


License :
-------
**Creative Commons Attribution 3.0** - http://creativecommons.org/licenses/by/3.0/

- You are allowed to use all files for both personal and commercial projects.

- If you use/modify the resources in your projects,we�d appreciate a linkback to this site.

- You do not have rights to redistribute,resell or offer files from this site to any third party

- If you wish to remove backlink from the template, you need to donate min USD $10 to remove backlink (credits) form the template

- If you have any question,feel free to contact us at webthemez@gmail.com

- All images user here is for demo purpose only, we are not responsible for any copyrights.